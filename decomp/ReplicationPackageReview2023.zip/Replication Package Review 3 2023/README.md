# Replication Package 

## Title:
Replication package for Decomposition of Monolithic Applications into Microservices Architectures: A Systematic Review.

## Authors:
 
 Yalemisew Abgaz, Andrew McCarren, Peter Elger, David Solan, Neil Lapuz, Marin Bivol, Glenn Jackson, Murat Yilmaz, Jim Buckley, and Paul Clarke 
 ## Year
 This replication package was initially generated in 2022, and following feedback from reviewers, it is revised in 2023.

This package contains two files and three folders that provide additional insight for researchers who wish to replicate our work or who would like to expand the review in the future. 

## Files
- **Literature_Search_Strategy.pdf/Literature_Search_Strategy.docx:** The file contains a detailed description of the literature search outlining the steps and the results obtained. 

- **Readme.md:** A readme file (this file). 
## Folders
- **Literature_Search_Data:** A folder containing the search results and the refinement steps. The folder contains four files listing studies included in the refinement process (Refinement_Step_1 to Refinement_Step_4) and a master file combining all the steps in one file. The master file contains detailed information about how the refinement steps are executed, and all the intermediate results following each refinement step. Users may explore by expanding the filters in Refinement Step 2 (J), Refinement Step 3 (M) and Refinement Step 4 (P) columns in the master sheet. Readers can also directly go to the sheets which contain the selected studies in any of the refinement stages. A description of each file is also included in the Literature_Search_Strategy.pdf file. 

- **Snowballing_Data:** This folder contains the list of studies included in the snowballing process, including the last two refinement steps (Refinement_Step_5 and Refinement_Step_6).  The snowballing master sheet contains studies extracted using the snowballing process and the data cleaning and filtering criteria used. The different sheets also contain the selected studies at each stage of the snowballing process.
 

- **SLR_GT_Data:** This folder contains the data extracted from the selected literature employing the Systematic Review and Ground Theory. The two files contain the data extraction template and the data extracted from the 35 selected studies  and intermediate notes.

If you have further questions regarding the survey, please, contact us via e-mail. Yalemisewm.abgaz@dcu.ie. 
